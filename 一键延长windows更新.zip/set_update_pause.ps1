﻿# 检查是否以管理员权限运行
function Test-IsAdministrator {
    return ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

# 如果当前不是管理员权限，则请求提升权限
if (-not (Test-IsAdministrator)) {
    $arguments = "& '" + $myinvocation.MyCommand.Definition + "'"
    Write-Host "请求以管理员权限运行此脚本..." -ForegroundColor Yellow
    Start-Process powershell -ArgumentList $arguments -Verb RunAs
    exit
}

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# 获取脚本目录
$scriptDirectory = $PSScriptRoot
if (-not $scriptDirectory) {
    $scriptDirectory = (Get-Location).Path
}

# 文件路径
$filePath = Join-Path -Path $scriptDirectory -ChildPath "pauseDays.json"

# 默认最大天数
$maxPauseDays = 299998

# 检查文件是否存在，不存在则创建一个包含299998的文件
if (-not (Test-Path $filePath)) {
    $initialData = @{ "Days" = $maxPauseDays } | ConvertTo-Json
    Set-Content -Path $filePath -Value $initialData
}

# 读取文件中的天数
$jsonContent = Get-Content -Path $filePath -Raw
$data = $jsonContent | ConvertFrom-Json
$pauseDays = [int]$data.Days

# 如果读取的天数超过最大值，则设置为最大值
if ($pauseDays -gt $maxPauseDays) {
    Write-Host "文件中的天数超过最大值 $maxPauseDays。将天数调整为最大值。" -ForegroundColor Yellow
    $pauseDays = $maxPauseDays
}

# 确保读取的天数在允许的范围内（1 到 299998）
if ($pauseDays -lt 1) {
    Write-Host "文件中的天数无效。将天数调整为 1。" -ForegroundColor Yellow
    $pauseDays = 1
}

$pauseStartDate = Get-Date
$pauseEndDate = $pauseStartDate.AddDays($pauseDays)
$expiryDate = $pauseStartDate.AddDays($pauseDays)

$pauseStartDateString = $pauseStartDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$pauseEndDateString = $pauseEndDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
$expiryDateString = $expiryDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")

$registryPath = "HKLM:\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings"

if (-not (Test-Path $registryPath)) {
    New-Item -Path $registryPath -Force | Out-Null
}

Set-ItemProperty -Path $registryPath -Name "FlightSettingsMaxPauseDays" -Value $pauseDays -Type DWord
Set-ItemProperty -Path $registryPath -Name "PauseFeatureUpdatesStartTime" -Value $pauseStartDateString -Type String
Set-ItemProperty -Path $registryPath -Name "PauseFeatureUpdatesEndTime" -Value $pauseEndDateString -Type String
Set-ItemProperty -Path $registryPath -Name "PauseQualityUpdatesStartTime" -Value $pauseStartDateString -Type String
Set-ItemProperty -Path $registryPath -Name "PauseQualityUpdatesEndTime" -Value $pauseEndDateString -Type String
Set-ItemProperty -Path $registryPath -Name "PauseUpdatesExpiryTime" -Value $expiryDateString -Type String

Write-Host "Windows暂停截止日期已延长至 $($pauseEndDate.ToString("yyyy-MM-dd"))..." -ForegroundColor Green
